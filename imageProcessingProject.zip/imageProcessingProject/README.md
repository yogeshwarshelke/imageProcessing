# image detection

1:	install Pycharm editor cummuinity version // or other editor also use

2:	cd PycharmProjects/imageprocessing

3:	create virutal environment
	
4:	pip3 install requirments1.txt

5: 	install sqlitestudio

6	Make sure all check path upadate like image,video,haarcasce .xml file, trining .yml file, Database file.

 
